* Part 1: warmup

No colab link, the part 1 notebook has no code. Please, read it and refer to the `main_notebook.ipynb` from `week0_07`.

* Part 2: Dealing with overfitting [![Open In Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/girafe-ai/ml-mipt/blob/21f_basic/homeworks_basic/lab02_deep_learning/Lab2_DL_part2_overfitting.ipynb)

* Part 3: Poetry generation [![Open In Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/girafe-ai/ml-mipt/blob/21f_basic/homeworks_basic/lab02_deep_learning/Lab2_DL_part3_poetry.ipynb)

* Parts 4 and 5 (_optional_): Signal and/or image classification [![Open In Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/girafe-ai/ml-mipt/blob/21f_basic/homeworks_basic/lab02_deep_learning/Lab2_DL_parts_4_and_5_optional.ipynb)
